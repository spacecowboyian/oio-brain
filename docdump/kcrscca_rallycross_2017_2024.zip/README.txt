KCRSCCA RallyCross 2017-2024 package

Contents
- tracked_results.json: structured results for Ian Jennings, Miles Smith, Ryan Redenbaugh, and Hudson Smith
- raw_urls_manifest.json: every raw-results URL I could identify from the KCRSCCA archive pages for 2017-2024
- raw_files_text/: text captures of the raw result pages and snippets I was able to extract

Important limitations
- Several 2021-2024 raw result pages returned HTTP 429 rate-limit errors through the browsing tool during collection.
- Because of that, this package mixes full text captures, partial text captures, and URL-only manifest entries.
- Hudson Smith had no identifiable 2017-2024 appearances in the accessible KCRSCCA RallyCross result pages. He does show up in 2025, but that year was outside the requested range.
